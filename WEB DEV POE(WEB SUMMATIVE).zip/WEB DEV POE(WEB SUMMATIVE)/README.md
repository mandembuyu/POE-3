# JEFE — Web Summative 

This repository contains a small static website for a fictional retail brand JEFE . It includes pages for browsing, cart/shopping bag handling, shipping, returns, careers, and basic navigation. The project is intentionally simple and uses plain HTML, CSS (inline in pages) and vanilla JavaScript. It's intended for demonstration and a summative web exercise.

## Files

- `index.html` — home page
- `woman.html`, `man.html`, `kid.html` — product/category pages
- `cart.html` — cart page (product listing, checkout actions)
- `shoppingbag.html` — shopping bag (empty state + dynamic rendering if items present)
- `shipping.html` — shipping information form (saves to `localStorage` key `shippingInfo`)
- `checkout.html` — checkout page (placeholder)
- `returns.html` — returns policy page
- `careers.html` — careers / openings page
- `style.css` — global styles (project uses a mix of inline styles and this file)
- `script.js` — site wide or page scripts (check individual pages for embedded scripts)
- `IMAGE/` — images used on the pages

## Quick start (view locally)

This is a static site — no build tool or server required. To run locally:

1. Open any `.html` file in your browser (double-click or right-click -> Open with > your browser).
2. For best results, open `index.html` and navigate via the site links.


## Shopping cart & shopping bag (local testing)

Cart state is stored in `localStorage` under the key `cart`. Each entry is an object with at least `{ id, name, price, quantity, image }`.

Example to populate a sample cart (paste in browser DevTools console):

```js
localStorage.setItem('cart', JSON.stringify([
  { id: 'p1', name: 'T-shirt', price: 199.99, quantity: 2, image: '' },
  { id: 'p2', name: 'Sneakers', price: 899.5, quantity: 1, image: '' }
]));
location.href = 'shoppingbag.html';
```

Then open `shoppingbag.html` or reload it — the page will render items from `localStorage` and show the order summary. Use the plus/minus controls or Remove buttons to change quantities; the page updates `localStorage` automatically.

To clear the cart:

```js
localStorage.setItem('cart', '[]');
location.reload();
```

## Shipping form

The `shipping.html` page contains a client-side form which validates required fields and saves the result to `localStorage` under the key `shippingInfo` when you click Continue to checkout. Example saved shape:

```json
{
  "fullName": "Gloire Mande",
  "phone": "+27 69 771 7220",
  "address1": "123 Main St",
  "address2": "Unit 5",
  "city": "Johannesburg",
  "state": "Johannesburg",
  "postal": "8001",
  "country": "South Africa",
  "notes": "Leave at reception",
  "savedAt": "2025-11-17Th..."
}
```

Open `shipping.html`, fill the form and submit to test this flow. The page redirects to `checkout.html` on success.

## Testing checklist

- Ensure `localStorage` is enabled in your browser.
- Populate `cart` with sample data and verify `shoppingbag.html` renders items and updates totals.
- Submit `shipping.html` with valid data and confirm `shippingInfo` is stored in `localStorage`.
- Try removing items from cart and confirm the empty-state appears again.

## Developer notes

- Pages currently use inline styles for many layout parts. Consider moving common styles into `style.css` for maintainability.
- Validation is client-side only (JS). If you integrate a backend, you must add server-side validation.
- Some pages (like `shoppingbag.html` and `cart.html`) share similar UI patterns — you can refactor duplicated code into `script.js` or componentized functions.

## Next improvements (suggested)

- Add a full list of countries for the shipping form.
- Provide sample data or a debug page to populate `localStorage` with test carts quickly.
- Extract repeated header/footer into includes or use a templating system if you convert to a build setup.

## License

This repo is provided as-is for demonstration. Add an appropriate license if you plan to publish or distribute.

## HTML → CSS → JS — A short practical guide (added)

This section walks you through the common developer workflow: start with HTML, add CSS for styling, then JavaScript for interactivity. It's written to help you intentionally build pages and scale the project.

Roles & order
- HTML — structure & content (what appears on the page)
- CSS — presentation & layout (how it looks)
- JavaScript — behavior & interactivity (how it behaves)

Think: build the content first (HTML), then style it (CSS), then add behavior (JS).

Practical step-by-step

1) Create a semantic HTML skeleton
- Use semantic elements: `<header>`, `<nav>`, `<main>`, `<section>`, `<article>`, `<footer>`.
- Add meaningful content and `id`/`class` hooks where you plan to style or script.

Example HTML skeleton

```html
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link rel="stylesheet" href="style.css">
  <title>JEFE — Example</title>
  <script src="script.js" defer></script>
</head>
<body>
  <header class="site-header">
    <h1>JEFE</h1>
  </header>
  <main class="container">
    <section id="products"></section>
  </main>
  <footer></footer>
  
</body>
</html>
```

2) Style with CSS (start mobile-first)
- Create `style.css` and link it from your HTML.
- Use variables for colors, and Flexbox/Grid for layout.
- Keep class names simple and reusable (e.g., `.container`, `.btn`, `.product-card`).

Minimal CSS example

```css
:root{--brand:#232323;--muted:#888}
body{font-family:system-ui,Segoe UI,Arial;margin:0;background:#fafafa;color:#222}
.container{max-width:1100px;margin:0 auto;padding:20px}
.grid{display:grid;grid-template-columns:1fr 320px;gap:20px}
@media(min-width:700px){.grid{grid-template-columns:1fr 320px}}
```

3) Add JavaScript for behavior
- Place `script.js` with `defer` or at the end of `<body>` so the DOM is available.
- Use event listeners, avoid inline handlers (e.g., `onclick` attributes).
- Keep logic modular: small functions for rendering, state updates, and storage.

Small JS pattern example

```js
document.addEventListener('DOMContentLoaded', () => {
  const list = document.getElementById('products');
  const cart = JSON.parse(localStorage.getItem('cart')||'[]');
  function render(){
    list.innerHTML = cart.map(p => `<div>${p.name} — R${p.price}</div>`).join('');
  }
  render();
});
```

Good practices & tips
- Accessibility: always use `<label>` with form inputs, `alt` attributes on images, and semantic headings in order.
- Progressive enhancement: ensure core functionality works without JS (forms submit), then improve with JS.
- Separation of concerns: keep HTML/CSS/JS files separate for maintainability.
- Small commits: use version control (git) and make atomic commits with meaningful messages.
- DevTools: use browser DevTools to inspect CSS, console errors, view `localStorage`, and step through JS.

Common workflow (iteration)
1. Build the HTML layout and content.
2. Add CSS and iterate the visual design across breakpoints.
3. Implement JS features (cart rendering, form handling). Test each change in the browser frequently.
4. Refactor duplicated code (extract shared components or helper functions).

Example: turning a static product list into an interactive cart
- Start: static `<ul>` of products in HTML.
- Step 1: add CSS card styles and grid layout.
- Step 2: add JS to handle "Add to cart" clicks and store items in `localStorage`.
- Step 3: create `shoppingbag.html` to read `localStorage` and render the cart, with quantity controls.

Where to from here (suggestions I can implement)
- Extract shared header/footer into `header.html`/`footer.html` fragments (or use a templating step).
- Move inline styles into `style.css` and create a small design system (`.btn`, `.card`, color variables).
- Add a small debug/test page that populates `localStorage` with sample cart data for faster testing.

---

