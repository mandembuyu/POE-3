// script.js - Main JavaScript file for the Jefe store
// send Email via EmailJS
const EMAILJS_SDK_URL = 'https://cdn.emailjs.com/sdk/3.11.0/email.min.js';
const EMAILJS_USER_ID = 'RdR7i2B-0Jd-ZVJd7'; // public key

/**
 * Ensure EmailJS SDK is loaded and initialized. Returns a Promise that
 * resolves when `window.emailjs` with `.send` is available.
 */
function ensureEmailJsLoaded() {
    return new Promise((resolve, reject) => {
        console.debug('[EmailJS] ensureEmailJsLoaded starting');
        if (window.emailjs && typeof window.emailjs.send === 'function') {
            console.debug('[EmailJS] emailjs already available');
            return resolve(window.emailjs);
        }

        // If a script tag for EmailJS already exists (any CDN variant), wait a bit
        const existingScript = Array.from(document.scripts).find(s => s.src && s.src.includes('emailjs.com')) || document.querySelector(`script[src="${EMAILJS_SDK_URL}"]`);
        console.debug('[EmailJS] looking for existing script tag:', existingScript && existingScript.src);
        if (existingScript) {
            // If there's already a script tag for the SDK, attach load/error handlers
            // and poll for initialization. Give more time (10s) because some
            // environments (slow networks) take longer.
            const onLoaded = () => {
                console.debug('[EmailJS] existing script load event');
                try {
                    if (window.emailjs && typeof window.emailjs.init === 'function') {
                        try { window.emailjs.init(EMAILJS_USER_ID); } catch(e) { /* ignore */ }
                    }
                    if (window.emailjs && typeof window.emailjs.send === 'function') {
                        cleanup();
                        console.debug('[EmailJS] initialized and send() available after load');
                        return resolve(window.emailjs);
                    }
                } catch (e) {
                    /* fallthrough to polling */
                }
            };
            const onErrored = () => {
                console.debug('[EmailJS] existing script error event');
                cleanup();
                return reject(new Error('EmailJS SDK script failed to load'));
            };

            const cleanup = () => {
                existingScript.removeEventListener('load', onLoaded);
                existingScript.removeEventListener('error', onErrored);
                if (iv) clearInterval(iv);
            };

            existingScript.addEventListener('load', onLoaded);
            existingScript.addEventListener('error', onErrored);

            // Also poll for up to 15s if load event already fired or init is delayed
            let waited = 0;
            const iv = setInterval(() => {
                if (window.emailjs && typeof window.emailjs.send === 'function') {
                    cleanup();
                    console.debug('[EmailJS] initialized and send() available during polling');
                    return resolve(window.emailjs);
                }
                // If emailjs exists but not initialized, attempt init again
                try {
                    if (window.emailjs && typeof window.emailjs.init === 'function') {
                        window.emailjs.init(EMAILJS_USER_ID);
                    }
                } catch (e) {
                    /* ignore init errors here */
                }
                waited += 300;
                if (waited >= 15000) {
                    cleanup();
                    return reject(new Error('EmailJS SDK present but did not initialize in time'));
                }
            }, 300);
            return;
        }

        // Otherwise dynamically load the SDK
        const script = document.createElement('script');
        script.src = EMAILJS_SDK_URL;
        script.async = true;
        script.onload = () => {
            console.debug('[EmailJS] dynamic SDK script loaded');
            try {
                if (!window.emailjs || typeof window.emailjs.init !== 'function') {
                    // emailjs should be available now; if not, error
                    return reject(new Error('EmailJS SDK loaded but `emailjs` not found'));
                }
                // Initialize with public key if not already initialized
                try {
                    if (EMAILJS_USER_ID && typeof window.emailjs.init === 'function') {
                        window.emailjs.init(EMAILJS_USER_ID);
                    }
                } catch (initErr) {
                    console.warn('EmailJS init failed:', initErr);
                }
                if (window.emailjs && typeof window.emailjs.send === 'function') {
                    console.debug('[EmailJS] send() is available after dynamic load');
                    return resolve(window.emailjs);
                }
                return reject(new Error('EmailJS loaded but send() not available'));
            } catch (e) {
                return reject(e);
            }
        };
        script.onerror = () => reject(new Error('Failed to load EmailJS SDK'));
        document.head.appendChild(script);
    });
}

// Helper for manual testing from the browser console
window.testEmailJs = function() {
    ensureEmailJsLoaded().then(() => {
        console.log('[EmailJS] ready:', !!window.emailjs && typeof window.emailjs.send === 'function');
    }).catch(err => {
        console.error('[EmailJS] ensureEmailJsLoaded failed:', err);
    });
};

function sendEmail() {
    // Get input elements
    const fromNameEl = document.getElementById("from_name");
    const toNameEl = document.getElementById("to_name");
    const phoneEl = document.getElementById("phone");
    const messageEl = document.getElementById("message");
    const replyToEl = document.getElementById("reply_to");
    const requireEl = document.getElementById("require"); // new required field

    // Validate inputs
    if (!fromNameEl || !toNameEl || !phoneEl || !messageEl || !replyToEl || !requireEl) {
        alert("Form error: missing required fields.");
        return;
    }
    const fromName = fromNameEl.value.trim();
    const toName = toNameEl.value.trim();
    const phone = phoneEl.value.trim();
    const message = messageEl.value.trim();
    const replyTo = replyToEl.value.trim();
    // For checkbox: requireEl.checked; for text: requireEl.value.trim()
    let requireValue = requireEl.type === 'checkbox' ? requireEl.checked : requireEl.value.trim();

    if (!fromName || !phone || !message || !replyTo || !requireValue) {
        alert("Please fill in all required fields (including requirements).");
        if (!requireValue) requireEl.focus();
        return;
    }
    // Simple phone format check
    if (!/^([0-9\s\-\+]{7,20})$/.test(phone)) {
        alert("Please enter a valid phone number.");
        phoneEl.focus();
        return;
    }
    // Simple email format check
    if (!/^\S+@\S+\.\S+$/.test(replyTo)) {
        alert("Please enter a valid email address.");
        replyToEl.focus();
        return;
    }

    var templateParams = {
        from_name: fromName,
        to_name: toName,
        phone: phone,
        message: message,
        reply_to: replyTo,
        require: requireValue // include in email params
    };

    // Ensure EmailJS is loaded (fallback to dynamic load) and then send
    ensureEmailJsLoaded()
        .then((emailjs) => {
            return emailjs.send('service_pvqsbsj', 'template_j9b5xwx', templateParams);
        })
        .then(function(response) {
            console.log('SUCCESS!', response.status, response.text);
            alert("Email sent successfully!");
        })
        .catch(function(error) {
            console.error('FAILED to send/emailjs error:', error);
            let errorMsg = "Failed to send email. Please try again.";
            if (error && error.text) {
                errorMsg += "\nDetails: " + error.text;
            } else if (error && error.message) {
                errorMsg += "\nDetails: " + error.message;
            }
            alert(errorMsg);
        });
}

// Cart functionality
let cart = JSON.parse(localStorage.getItem('cart')) || [];

// Initialize cart on page load
document.addEventListener('DOMContentLoaded', function() {
    updateCartCount();
    initializeAddToCartButtons();
});

// Add product to cart
function addToCart(productId, productName, productPrice, productImage) {
    const product = {
        id: productId,
        name: productName,
        price: parseFloat(productPrice),
        image: productImage || '',
        quantity: 1
    };
    
    // Check if product already exists in cart
    const existingProduct = cart.find(item => item.id === productId);
    
    if (existingProduct) {
        existingProduct.quantity += 1;
    } else {
        cart.push(product);
    }
    
    // Save to localStorage
    localStorage.setItem('cart', JSON.stringify(cart));
    
    // Update cart count
    updateCartCount();
    
    // Show notification
    showNotification('Product added to cart!');
}

// Remove product from cart
function removeFromCart(productId) {
    cart = cart.filter(item => item.id !== productId);
    localStorage.setItem('cart', JSON.stringify(cart));
    updateCartCount();
    
    // Reload cart page if on cart page
    if (window.location.pathname.includes('cart.html')) {
        location.reload();
    }
}

// Update quantity in cart
function updateCartQuantity(productId, quantity) {
    const product = cart.find(item => item.id === productId);
    if (product) {
        if (quantity <= 0) {
            removeFromCart(productId);
        } else {
            product.quantity = quantity;
            localStorage.setItem('cart', JSON.stringify(cart));
            updateCartCount();
            
            // Reload cart page if on cart page
            if (window.location.pathname.includes('cart.html')) {
                location.reload();
            }
        }
    }
}

// Get cart total
function getCartTotal() {
    return cart.reduce((total, item) => total + (item.price * item.quantity), 0);
}

// Get cart count
function getCartCount() {
    return cart.reduce((count, item) => count + item.quantity, 0);
}

// Update cart count display
function updateCartCount() {
    const cartCountElements = document.querySelectorAll('.cart-count');
    const count = getCartCount();
    
    cartCountElements.forEach(element => {
        element.textContent = count;
    });
}

// Initialize add to cart buttons
function initializeAddToCartButtons() {
    const addToCartButtons = document.querySelectorAll('.product button, .add-to-cart');
    
    addToCartButtons.forEach(button => {
        button.addEventListener('click', function() {
            const productCard = this.closest('.product');
            if (productCard) {
                const productName = productCard.querySelector('h3')?.textContent || 'Product';
                const productPrice = productCard.querySelector('.price')?.textContent?.replace('R', '').replace(',', '') || '0';
                const productImage = productCard.querySelector('img')?.src || '';
                const productId = productCard.dataset.productId || Date.now().toString();
                
                addToCart(productId, productName, productPrice, productImage);
            }
        });
    });
}

// Clear cart
function clearCart() {
    cart = [];
    localStorage.setItem('cart', JSON.stringify(cart));
    updateCartCount();
    
    if (window.location.pathname.includes('cart.html')) {
        location.reload();
    }
}

// Checkout function
function checkout() {
    if (cart.length === 0) {
        alert('Your cart is empty!');
        return;
    }
    
    const total = getCartTotal();
    alert(`Proceeding to checkout. Total: R${total.toFixed(2)}`);
    // Redirect to checkout page
    window.location.href = 'checkout.html';
}

// Search functionality
function initializeSearch() {
    const searchInputs = document.querySelectorAll('.search-bar input');
    const searchButtons = document.querySelectorAll('.search-bar button');
    
    searchButtons.forEach((button, index) => {
        button.addEventListener('click', function() {
            const searchTerm = searchInputs[index].value.trim();
            if (searchTerm) {
                performSearch(searchTerm);
            }
        });
    });
    
    searchInputs.forEach(input => {
        input.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                const searchTerm = this.value.trim();
                if (searchTerm) {
                    performSearch(searchTerm);
                }
            }
        });
    });
}

// Perform search
function performSearch(searchTerm) {
    // Simple search - filter products by name
    const products = document.querySelectorAll('.product');
    let found = false;
    
    products.forEach(product => {
        const productName = product.querySelector('h3')?.textContent.toLowerCase() || '';
        const productDesc = product.querySelector('p')?.textContent.toLowerCase() || '';
        
        if (productName.includes(searchTerm.toLowerCase()) || productDesc.includes(searchTerm.toLowerCase())) {
            product.style.display = 'flex';
            found = true;
        } else {
            product.style.display = 'none';
        }
    });
    
    if (!found) {
        showNotification('No products found matching your search.');
    }
}

// Show notification
function showNotification(message) {
    // Create notification element
    const notification = document.createElement('div');
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background-color: #333;
        color: #fff;
        padding: 15px 20px;
        border-radius: 5px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.2);
        z-index: 1000;
        animation: slideIn 0.3s ease;
    `;
    notification.textContent = message;
    
    // Add animation
    const style = document.createElement('style');
    style.textContent = `
        @keyframes slideIn {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }
    `;
    document.head.appendChild(style);
    
    document.body.appendChild(notification);
    
    // Remove after 3 seconds
    setTimeout(() => {
        notification.style.animation = 'slideIn 0.3s ease reverse';
        setTimeout(() => {
            notification.remove();
        }, 300);
    }, 3000);
}

// Initialize search on page load
document.addEventListener('DOMContentLoaded', function() {
    initializeSearch();
});

// Export functions for use in other scripts
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        addToCart,
        removeFromCart,
        updateCartQuantity,
        getCartTotal,
        getCartCount,
        clearCart,
        checkout
    };
}
